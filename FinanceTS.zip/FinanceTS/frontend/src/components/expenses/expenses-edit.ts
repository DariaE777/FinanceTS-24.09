import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";

export class ExpensesEdit {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    private categoryEditInputElement: HTMLElement | null = document.getElementById('expense-edit-input');
    private originalExpenseData: CategoriesResponseType | null = null;
    readonly expenseEditElement: HTMLElement | null = document.getElementById('expense-edit');
    readonly expenseEditCancelElement: HTMLElement | null = document.getElementById('expense-edit-cancel');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
        const urlId = urlParams.get('id')
        if (urlId) {
            const id: number = parseInt(urlId);
            if (!id) {
                return this.openNewRoute('/');
            }
            if (this.expenseEditElement) {
                this.expenseEditElement.addEventListener('click', this.editExpense.bind(this));
            }

            if( this.expenseEditCancelElement) {
                this.expenseEditCancelElement.addEventListener('click', this.notEdit.bind(this));
            }
            this.getExpensesCategory(id).then();
        }
    }
    private async getExpensesCategory(id: number): Promise<Response | undefined> {
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };
        const response: Response = await fetch(host + 'categories/expense/' + id, params);
        const result: CategoriesResponseType | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });

                if (updateTokenResult.status === 200) {
                    const tokens = await updateTokenResult.json();

                    if (tokens && !tokens.error) {
                        Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }
        }
        (this.categoryEditInputElement as HTMLInputElement).value = (result as CategoriesResponseType).title;
        this.originalExpenseData = result as CategoriesResponseType;
    }

    private async editExpense(e:MouseEvent): Promise<Response | undefined> {
        e.preventDefault();
        const changedData: CategoriesResponseType | {} = {};
        if (this.originalExpenseData) {
            if ((this.categoryEditInputElement as HTMLInputElement).value !== this.originalExpenseData.title) {
                (changedData as CategoriesResponseType).title = (this.categoryEditInputElement as HTMLInputElement).value;
            }

            if ((changedData as CategoriesResponseType).title) {
                const params: RequestInit = {
                    method: 'PUT',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json',
                        'x-auth-token': this.token ?? '',
                    },
                    body: JSON.stringify(changedData)
                };
                const response: Response = await fetch(host + 'categories/expense/' + this.originalExpenseData.id, params);
                const result: CategoriesResponseType | DefaultResponseType = await response.json();
                if (!result || (result as DefaultResponseType).error) {
                    console.log((result as DefaultResponseType).message);
                } else {
                    return this.openNewRoute('/expenses');
                }
            }

        }
    }

    private notEdit(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/expenses');
    }
}