import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";
import {RefreshResponseType} from "../../types/refresh-response.type";

export class Expenses {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly expenseCategories: HTMLElement | null = document.getElementById('expenses-categories');
    readonly insertBeforeElement: HTMLElement | null = document.getElementById('add-expenses-category');
    readonly popupElement: HTMLElement | null = document.getElementById('popup-expenses');
    private categoryId: number | null = null;
    private categoryElement: HTMLElement | null = document.createElement('div');
    private expensesDeleteCategoryButton: HTMLElement | null = document.getElementById('expenses-delete-category-cancel');
    private expensesDeleteCategoryCancelButton: HTMLElement | null = document.getElementById('expenses-delete-category');
    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);

        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        this.getExpensesCategories().then();
        if(this.expensesDeleteCategoryButton) {
            this.expensesDeleteCategoryButton.addEventListener('click', this.deleteCategory.bind(this));
        }
        if(this.expensesDeleteCategoryCancelButton) {
            this.expensesDeleteCategoryCancelButton.addEventListener('click', this.closePopup.bind(this));
        }
    }

    private async getExpensesCategories(): Promise<Response | undefined> {
        const params: RequestInit = {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
                'x-auth-token': this.token ?? '',
            }
        };

        const response: Response = await fetch(host + 'categories/expense', params);
        const result: CategoriesResponseType[] | DefaultResponseType = await response.json();
        if (!result || (result as DefaultResponseType).error) {
            if (response.status === 401) {
                const updateTokenResult: Response = await fetch(host + 'refresh', {
                    method: 'POST',
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({refreshToken: this.refreshToken})
                });
                if (updateTokenResult && updateTokenResult.status === 200) {
                    const tokens: RefreshResponseType | DefaultResponseType = await updateTokenResult.json();
                    if (tokens && !(tokens as DefaultResponseType).error && (tokens as RefreshResponseType).tokens.accessToken && (tokens as RefreshResponseType).tokens.refreshToken) {
                        Auth.setTokens((tokens as RefreshResponseType).tokens.accessToken, (tokens as RefreshResponseType).tokens.refreshToken);
                        return response;
                    }
                } else {
                    Auth.removeTokens();
                    localStorage.removeItem(Auth.userInfoKey);
                    this.openNewRoute('/login');
                }
            }
        }
        await this.showCategories(result as CategoriesResponseType[]);
    }
    private async showCategories(categories:CategoriesResponseType[]): Promise<void> {
        for (let i = 0; i < categories.length; i++) {
            if (this.categoryElement) {
                this.categoryElement.className = 'expenses-category col-4';
                const categoryTitleElement: HTMLHeadingElement | null = document.createElement('h2');
                if(categoryTitleElement) {
                    categoryTitleElement.innerText = categories[i].title;
                }

                this.categoryElement.appendChild(categoryTitleElement);
                const buttonGroupElement: HTMLDivElement = document.createElement('div');
                buttonGroupElement.className = 'button-group';
                buttonGroupElement.innerHTML = '<a href="/expenses/edit?id=' + categories[i].id + '" class="btn btn-primary me-1">Редактировать</a>\n' +
                    '<a class="btn btn-danger expense-category-delete-button" >Удалить</a>';
                this.categoryElement.appendChild(buttonGroupElement);
                if (this.expenseCategories && this.insertBeforeElement) {
                    this.expenseCategories.insertBefore(this.categoryElement, this.insertBeforeElement);
                }
                let deleteButton: any = document.querySelectorAll('.expense-category-delete-button')[i];
                deleteButton.addEventListener('click', this.openPopup.bind(this));
                deleteButton.category_id = categories[i].id;
            }
        }
    }

    private openPopup(e:any): void {
        e.preventDefault();
        if (this.popupElement) {
            this.popupElement.style.display = 'block';
        }
        this.categoryId = e.currentTarget.category_id;
    }
    private closePopup(e:MouseEvent): void {
        e.preventDefault();
        if (this.popupElement) {
            this.popupElement.style.display = 'none';
        }
    }
   private deleteCategory(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/expenses/delete?id=' + this.categoryId);
    }
}