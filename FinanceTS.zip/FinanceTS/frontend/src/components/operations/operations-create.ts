import {Auth} from "../../auth";
import host from "../../config/config";
import {CategoriesResponseType} from "../../types/categories-response.type";
import {DefaultResponseType} from "../../types/default-response.type";


export class OperationsCreate {
    readonly openNewRoute: Function;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly typeElement: HTMLElement | null = document.getElementById('type-create-input');
    readonly categoryInputElement: HTMLElement | null = document.getElementById('category-create-input');
    readonly operationCreateTitle: HTMLElement | null = document.getElementById('operation-create-title');
    readonly sumElement: HTMLElement | null = document.getElementById('sum-create-input');
    readonly dateElement: HTMLElement | null = document.getElementById('date-create-input');
    readonly commentElement: HTMLElement | null = document.getElementById('comment-create-input');
    readonly errorCategoryElement: HTMLElement | null = document.getElementById('error-category');
    readonly errorSumElement: HTMLElement | null = document.getElementById('error-sum');
    readonly errorDateElement: HTMLElement | null = document.getElementById('error-date');
    readonly errorCommentElement: HTMLElement | null = document.getElementById('error-comment');
    private categoryIdElement: number | null = null;
    readonly operationCreateElement: HTMLElement | null = document.getElementById('operation-create');
    readonly operationCreateCancelElement: HTMLElement | null =  document.getElementById('operation-create-cancel');
    readonly categoryCreateInput: HTMLElement | null = document.getElementById('category-create-input');
    readonly pageElement: string | null = null;

    constructor(openNewRoute:Function) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            return this.openNewRoute('/login');
        }
        const urlParams: URLSearchParams = new URLSearchParams(window.location.search);
        this.pageElement = urlParams.get('page');
        if (this.pageElement === 'income' && this.operationCreateTitle && this.typeElement) {
            this.operationCreateTitle.innerText = 'Создание дохода';
            (this.typeElement as HTMLInputElement).placeholder = 'Доход';
        }
        if (this.pageElement === 'expense' && this.operationCreateTitle && this.typeElement) {
            this.operationCreateTitle.innerText = 'Создание расхода';
            (this.typeElement as HTMLInputElement).placeholder = 'Расход';
        }
        this.createCategoryOptions().then();
        if (this.operationCreateElement) {
            this.operationCreateElement.addEventListener('click', this.createOperation.bind(this));
        }
        if (this.operationCreateCancelElement) {
            this.operationCreateCancelElement.addEventListener('click', this.cancelOperation.bind(this));
        }
    }

    private validate(): boolean | undefined {
        if (this.errorCategoryElement && this.errorSumElement && this.errorDateElement && this.errorCommentElement
            && this.categoryInputElement && this.sumElement && this.dateElement && this.commentElement) {
            this.errorCategoryElement.style.display = 'none';
            this.errorSumElement.style.display = 'none';
            this.errorDateElement.style.display = 'none';
            this.errorCommentElement.style.display = 'none';
            this.categoryInputElement.classList.add('mb-4');
            this.sumElement.classList.add('mb-4');
            this.dateElement.classList.add('mb-4');
            this.commentElement.classList.add('mb-4');
            if ((this.categoryInputElement as HTMLInputElement).value === 'Категория...') {
                this.errorCategoryElement.style.display = 'block';
                this.categoryInputElement.classList.remove('mb-4');
            }
            if (!(this.sumElement as HTMLInputElement).value) {
                this.errorSumElement.style.display = 'block';
                this.sumElement.classList.remove('mb-4');
                return false;
            }
            if (!(this.dateElement as HTMLInputElement).value) {
                this.errorDateElement.style.display = 'block';
                this.dateElement.classList.remove('mb-4');
                return false;
            }
            if (!(this.commentElement as HTMLInputElement).value) {
                this.errorCommentElement.style.display = 'block';
                this.commentElement.classList.remove('mb-4');
                return false;
            } else {
                return true;
            }
        }
    }

    private getId(result: CategoriesResponseType[]): number | null {
        let chosenIndex: number = (this.categoryInputElement as HTMLSelectElement).selectedIndex;
        this.categoryIdElement = result[chosenIndex - 1].id;
        return this.categoryIdElement;
    }

    private async createCategoryOptions(): Promise<Response | undefined> {
        let response: Response | null = null;
        if (this.token !== null) {
            const params: RequestInit = {
                method: 'GET',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token,
                }
        }
            if (this.pageElement === 'income') {
                response = await fetch(host + 'categories/income', params);
            } else {
                response = await fetch(host + 'categories/expense', params);
            }
        }
        if (response) {
            const result: CategoriesResponseType[] | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();
                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
            }

            for (let i = 0; i < (result as CategoriesResponseType[]).length; i++) {
                const optionElement: HTMLOptionElement = document.createElement('option');
                optionElement.innerText = (result as CategoriesResponseType[])[i].title;
                if (this.categoryInputElement) {
                    this.categoryInputElement.appendChild(optionElement);
                }
            }
            if (this.categoryCreateInput) {
                this.categoryCreateInput.addEventListener("change", () => this.getId(result as CategoriesResponseType[]));
            }
        }

    }
    private async createOperation(e:MouseEvent): Promise<Response | undefined> {
        e.preventDefault();

        if (this.validate()) {
            const params:RequestInit = {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token ?? '',
                },
                body: JSON.stringify({
                    type: this.pageElement,
                    amount: (this.sumElement as HTMLInputElement).value,
                    date: (this.dateElement as HTMLInputElement).value,
                    comment: (this.commentElement as HTMLInputElement).value,
                    category_id: this.categoryIdElement
                })
            }
            const response: Response = await fetch(host + 'operations', params);
            const result: CategoriesResponseType | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();
                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
                return this.openNewRoute('/login');
            }
            return this.openNewRoute('/operations');
        }
    }

    private cancelOperation(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/operations');
    }
}