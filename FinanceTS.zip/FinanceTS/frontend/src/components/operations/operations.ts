import {Auth} from "../../auth";
import host from "../../config/config";
import {GetOperationsResponseType} from "../../types/get-operations-response.type";
import {DefaultResponseType} from "../../types/default-response.type";


export class Operations {
    readonly openNewRoute: (arg0: string) => void;
    readonly token: string | null;
    readonly refreshToken: string | null;
    readonly operationIncomeCreate: HTMLElement | null;
    readonly operationExpenseCreate: HTMLElement | null;
    private param: string | null = null;
    readonly date: string[] | null;
    readonly today: string;
    readonly dateFrom: HTMLElement | null = document.getElementById('date-from');
    readonly dateTo: HTMLElement | null = document.getElementById('date-to');
    private operationId: number | null = null;
    readonly popupElement: HTMLElement | null = document.getElementById('popup-operations');
    readonly operationDeleteButton: any  = document.getElementById('operation-delete');
    readonly cancelDeleteButton: HTMLElement | null = document.getElementById('operation-delete-cancel');
    readonly operationsTableElement: HTMLElement | null = document.getElementById('operations-table');
    readonly intervalOperationsButton: HTMLElement | null = document.getElementById('interval-operations');
    readonly todayOperations: HTMLElement | null = document.getElementById('today-operations');
    readonly weekOperations: HTMLElement | null = document.getElementById('week-operations');
    readonly monthOperations: HTMLElement | null = document.getElementById('month-operations');
    readonly yearOperations: HTMLElement | null = document.getElementById('year-operations');
    readonly allOperations: HTMLElement | null = document.getElementById('all-operations');
    readonly openPopupEl: HTMLElement | null = document.getElementById('open-popup');
    constructor(openNewRoute:(arg0: string) => void) {
        this.openNewRoute = openNewRoute;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            this.openNewRoute('/login');
        }
        this.operationIncomeCreate = document.getElementById('operation-income-create');
        if (this.operationIncomeCreate) {
            this.operationIncomeCreate.addEventListener('click', this.incomeCreate.bind(this));
        }
        this.operationExpenseCreate = document.getElementById('operation-expense-create');
        if (this.operationExpenseCreate) {
            this.operationExpenseCreate.addEventListener('click', this.expenseCreate.bind(this));
        }

        this.date = new Date().toLocaleDateString().split('.');
        this.today = this.date[2] + '-' + this.date[1] + '-' + this.date[0];
        if (this.operationDeleteButton) {
            this.operationDeleteButton.addEventListener('click', this.confirmDeleting.bind(this));
        }
        if (this.cancelDeleteButton) {
            this.cancelDeleteButton.addEventListener('click', this.cancelDeleting.bind(this));
        }
        if (this.todayOperations) {
            this.todayOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'interval&dateFrom=' + this.today + '&dateTo=' + this.today));
        }
        if (this.weekOperations) {
            this.weekOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'week'));
        }
        if (this.monthOperations) {
            this.monthOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'month'));
        }
        if (this.yearOperations) {
            this.yearOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'year'));
        }
        if (this.allOperations) {
            this.allOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'all'));
        }
        if (this.intervalOperationsButton) {
            this.intervalOperationsButton.addEventListener('click', () => this.getIntervalOperations());
        }
        this.getOperations(null, this.param = 'interval&dateFrom=' + this.today + '&dateTo=' + this.today).then();
    }

    private incomeCreate(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/operations/create?page=income');
    }

    private expenseCreate(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/operations/create?page=expense');
    }

    private getIntervalOperations(): void {
        if (this.dateTo && this.dateFrom && this.intervalOperationsButton) {
            this.dateTo.removeAttribute('disabled');
            this.dateFrom.removeAttribute('disabled');
            this.dateTo.setAttribute('type', 'date');
            this.dateFrom.setAttribute('type', 'date');
            this.intervalOperationsButton.classList.add('active');
            this.dateTo.addEventListener('input', () => this.getOperations(null, this.param = 'interval&dateFrom=' + (this.dateFrom as HTMLInputElement).value + '&dateTo=' + (this.dateTo as HTMLInputElement).value));
        }
        document.querySelectorAll('.btn-filter').forEach(item => {
            item.classList.remove('active');
        });
    }

    private async getOperations(e:MouseEvent | null, param:string): Promise<Response | undefined> {
        if (e) {
            if (this.dateTo && this.dateFrom) {
                this.dateFrom.setAttribute('type', 'text');
                this.dateTo.setAttribute('type', 'text');
                this.dateTo.setAttribute('disabled', 'true');
                this.dateFrom.setAttribute('disabled', 'true');
            }
            document.querySelectorAll('.btn-filter').forEach(item => {
                item.classList.remove('active');
                if(e.target instanceof HTMLElement) {
                   e.target.classList.add('active');
                }
               
            });
            if ((this.dateFrom as HTMLInputElement).value && (this.dateTo as HTMLInputElement).value) {
                (this.dateFrom as HTMLInputElement).value = '';
                (this.dateTo as HTMLInputElement).value = '';
            }
        }

        const newOperationBlocks: NodeListOf<Element> = document.querySelectorAll('div.new-operation-block');
        if (newOperationBlocks) {
            newOperationBlocks.forEach(item => {
                item.remove();
            })
        }
        if (this.token) {
            const params:RequestInit = {
                method: 'GET',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token,
                }
            };
            const response: Response = await fetch(host + 'operations?period=' + param, params);
            const result: GetOperationsResponseType[] | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult = await fetch(host + 'api/refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens = await updateTokenResult.json();
                        if (tokens && !tokens.error) {
                            Auth.setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
                this.openNewRoute('/login');
            }
            await this.showOperations(result as GetOperationsResponseType[]);
        }
    }

    private async showOperations(operations: GetOperationsResponseType[]): Promise<void> {
        for (let i = 0; i < operations.length; i++) {
            const numberElement: HTMLElement = document.createElement('div');
            numberElement.classList.add('col', 'col-number');
            numberElement.innerText = (i + 1).toString();
            const operationType: HTMLElement = document.createElement('div');
            operationType.classList.add('col');
            if (operations[i].type === 'income') {
                operationType.innerText = 'Доход';
                operationType.style.color = '#198754';
            }
            if (operations[i].type === 'expense') {
                operationType.innerText = 'Расход';
                operationType.style.color = '#DC3545';
            }
            const operationCategory: HTMLElement = document.createElement('div');
            operationCategory.classList.add('col');
            operationCategory.innerText = operations[i].category;
            const sumElement: HTMLElement = document.createElement('div');
            sumElement.classList.add('col');
            sumElement.innerText = operations[i].amount + '$';
            const dateElement: HTMLElement = document.createElement('div');
            dateElement.classList.add('col');
            const date: string[] = operations[i].date.split('-');
            dateElement.innerText = date[2] + '.' + date[1] + '.' + date[0];
            const commentElement: HTMLElement = document.createElement('div');
            commentElement.classList.add('col');
            commentElement.innerText = operations[i].comment;
            const actionsElement: HTMLElement = document.createElement('div');
            actionsElement.classList.add('col');
            const iconsElement: HTMLElement = document.createElement('div');
            iconsElement.classList.add('icons', 'd-flex', 'justify-content-center');
            const trashEl: HTMLElement = document.createElement('a');
            trashEl.setAttribute('id', 'open-popup');
            trashEl.setAttribute('href', 'javascript:void(0);');
            trashEl.classList.add('bi', 'bi-trash');
            const pencilEl: HTMLElement = document.createElement('a');
            pencilEl.setAttribute('href', '/operations/edit?id=' + operations[i].id)
            pencilEl.classList.add('bi', 'bi-pencil');
            iconsElement.appendChild(trashEl);
            iconsElement.appendChild(pencilEl);
            actionsElement.appendChild(iconsElement);
            const newOperation: HTMLElement = document.createElement('div');
            newOperation.classList.add('row');
            newOperation.classList.add('new-operation-block');
            newOperation.appendChild(numberElement);
            newOperation.appendChild(operationType);
            newOperation.appendChild(operationCategory);
            newOperation.appendChild(sumElement);
            newOperation.appendChild(dateElement);
            newOperation.appendChild(commentElement);
            newOperation.appendChild(actionsElement);
            if (this.operationsTableElement) {
                this.operationsTableElement.appendChild(newOperation);
            }
            if (this.openPopupEl) {
                this.openPopupEl.addEventListener('click', this.openPopup.bind(this));
            }
            if (this.operationDeleteButton) {
                this.operationDeleteButton.operationId = operations[i].id;
            }

        }
    }
    private openPopup(e: MouseEvent): void {
        e.preventDefault();
        if (this.popupElement) {
            this.popupElement.style.display = 'block';
        }
    }
    private confirmDeleting(e: any): void {
        e.preventDefault();
        this.operationId = e.currentTarget.operationId;
        this.openNewRoute('/operations/delete?id=' + this.operationId);
    }
    private cancelDeleting(e:MouseEvent): void {
        e.preventDefault();
        this.openNewRoute('/operations');
    }
}