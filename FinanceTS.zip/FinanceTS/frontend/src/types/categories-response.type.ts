export type CategoriesResponseType = {
    id: number,
    title: string
}