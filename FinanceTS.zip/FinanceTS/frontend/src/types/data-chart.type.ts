export type  DataChartType = {
    [key: string]: number;
}