
export type RouteType = {
    route:  string,
    title?: string | undefined,
    filePathTemplate?: string | undefined,
    useLayout?: boolean | string | undefined,
    load(): void
}